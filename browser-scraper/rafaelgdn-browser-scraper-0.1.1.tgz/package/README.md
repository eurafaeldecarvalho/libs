# Browser Scraper

`@rafaelgdn/browser-scraper` is a CDP-first browser scraping package for Node.js, preserving the same public API and the same design direction used in the original GDNox prototype.

## Status

This package has the core ported:

- Direct Chrome launch with raw CDP
- Tab/page control
- Unified DOM search with shadow root piercing
- OOP iframe support
- Element interactions
- Network monitoring and interception
- Profile seeding

## Install

```bash
pnpm install
```

If `pnpm` blocks native build scripts, run:

```bash
pnpm rebuild better-sqlite3 esbuild
```

## Usage

```ts
import { Browser } from "@rafaelgdn/browser-scraper";

const browser = new Browser();

try {
  const tab = await browser.new_tab();
  await tab.goto("https://example.com");

  const heading = await tab.find("h1");
  console.log(await heading?.text());
} finally {
  await browser.close();
}
```

## API

### Browser

```ts
new Browser({
  chrome_path: null,
  headless: false,
  user_data_dir: null,
  proxy: null,
  extra_args: [],
  auto_seed: true,
});
```

### Tab

```ts
await tab.goto(url, "load", 30);
await tab.find(selector, 5);
await tab.find_all(selector);
await tab.wait_for_selector(selector, false, false, 30);
await tab.wait_for_function(expression, 30);
await tab.race([".success"], ["window.done === true"], false, 30);
await tab.evaluate("document.title");
await tab.screenshot("shot.png");
await tab.content();
await tab.sleep(2);
```

### Element

```ts
await element.click();
await element.type("hello");
await element.text();
await element.inner_html();
await element.get_attribute("href");
await element.set_attribute("data-test", "1");
await element.is_visible();
```

## Notes

- The port currently mirrors the real implemented behavior in the Python package.
- The dedicated fingerprint and runtime stealth modules were removed from the Node package because enabling them increased Cloudflare detection in testing.

## Publish

Build the package first:

```bash
pnpm build
```

Inspect the publishable tarball locally:

```bash
pnpm pack
```

Log into npm:

```bash
npm login
npm whoami
```

Publish the scoped package publicly:

```bash
pnpm publish --access public --no-git-checks
```