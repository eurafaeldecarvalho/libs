# Browser Scraper

`@rafaelgdn/browser-scraper` is a CDP-first browser scraping package for Node.js, preserving the same public API and the same design direction used in the original GDNox prototype.

## Status

This package has the core ported:

- Direct Chrome launch with raw CDP
- Tab/page control
- Unified DOM search with shadow root piercing
- OOP iframe support
- Element interactions
- Network monitoring and interception
- Profile seeding

## Install

```bash
pnpm install
```

If `pnpm` blocks native build scripts, run:

```bash
pnpm rebuild better-sqlite3 esbuild
```

## Usage

```ts
import { Browser } from "@rafaelgdn/browser-scraper";

const browser = new Browser();

try {
  const tab = await browser.newTab();
  await tab.goto({ url: "https://example.com" });

  const heading = await tab.find({ selector: "h1" });
  console.log(await heading?.text());
} finally {
  await browser.close();
}
```

## API

### Browser

```ts
new Browser({
  chromePath: null,
  headless: false,
  userDataDir: null,
  proxy: null,
  extraArgs: [],
  autoSeed: true,
});
```

### Tab

```ts
await tab.goto({ url, waitUntil: "load", timeout: 30_000 });
await tab.waitForNavigation({ waitUntil: "networkidle2", timeout: 30_000 });
await tab.find({ selector, timeout: 5_000 });
await tab.findAll({ selector });
await tab.waitForSelector({ selector, state: "attached", timeout: 30_000 });
await tab.waitForSelector({ selector, state: "ready", timeout: 30_000 });
await tab.waitForFunction({ expression, timeout: 30_000 });
await tab.race({ selectors: [".success"], jsFunctions: ["window.done === true"], visible: false, timeout: 30_000 });
await tab.evaluate({ expression: "document.title" });
await tab.screenshot({ path: "shot.png" });
await tab.content();
await tab.sleep({ milliseconds: 2_000 });
```

`waitUntil` follows the same public names used by Puppeteer: `load`, `domcontentloaded`, `networkidle0`, and `networkidle2`.
All timeouts and sleeps are expressed in milliseconds.
`waitForSelector({ state: "visible" })` waits only for visibility.
`waitForSelector({ state: "ready" })` waits for visibility plus interactability, including enabled/not-busy checks for common button states.

### Element

```ts
await element.click();
await element.type({ text: "hello", clear: true });
await element.text();
await element.innerHtml();
await element.getAttribute({ name: "href" });
await element.setAttribute({ name: "data-test", value: "1" });
await element.isVisible();
```

## Notes

- The port currently mirrors the real implemented behavior in the Python package.
- The dedicated fingerprint and runtime stealth modules were removed from the Node package because enabling them increased Cloudflare detection in testing.

## Publish

Build the package first:

```bash
pnpm build
```

Inspect the publishable tarball locally:

```bash
pnpm pack
```

Log into npm:

```bash
npm login
npm whoami
```

Publish the scoped package publicly:

```bash
pnpm publish --access public --no-git-checks
```